<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            text-align: center;
            background-color: #f4f4f4;
        }
        img {
            max-width: 100%;
                        width: 100%; /* Full width of the page */

            height: auto;
            width: auto;
            margin-bottom: 20px;
            border: 2px solid #ccc;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
         .full-width {
            width: 100%; /* Full width of the page */
            height: 30vh; /* Still 30% of viewport height */
            margin-bottom: 20px;
            border-radius: 0; /* Remove rounded corners for full-width image */
        }
    </style>
</head>
<body>

    <img src="about_us_ar.jpg" alt="Image 1">
</body>
</html>
